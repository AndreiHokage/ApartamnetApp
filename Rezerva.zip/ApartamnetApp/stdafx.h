#pragma once
class stdafx
{
};

