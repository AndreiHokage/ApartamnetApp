#pragma once
#include "Test.h"
#include "Repo_locatari.h"
#include "Controller_Locatari.h"
#include "Validator.h"
#include "UI.h"
#include "Myvector.h"
#include "Repo_locatari_file.h"

class AppCoord
{

public:
	AppCoord() = default; 

	void run();
};

