#include "ApartamnetApp.h"

ApartamnetApp::ApartamnetApp(QWidget *parent)
    : QMainWindow(parent)
{
    ui.setupUi(this);
}
