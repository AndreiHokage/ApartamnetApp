/********************************************************************************
** Form generated from reading UI file 'ApartamnetApp.ui'
**
** Created by: Qt User Interface Compiler version 6.0.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_APARTAMNETAPP_H
#define UI_APARTAMNETAPP_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ApartamnetAppClass
{
public:
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QWidget *centralWidget;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *ApartamnetAppClass)
    {
        if (ApartamnetAppClass->objectName().isEmpty())
            ApartamnetAppClass->setObjectName(QString::fromUtf8("ApartamnetAppClass"));
        ApartamnetAppClass->resize(600, 400);
        menuBar = new QMenuBar(ApartamnetAppClass);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        ApartamnetAppClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(ApartamnetAppClass);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        ApartamnetAppClass->addToolBar(mainToolBar);
        centralWidget = new QWidget(ApartamnetAppClass);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        ApartamnetAppClass->setCentralWidget(centralWidget);
        statusBar = new QStatusBar(ApartamnetAppClass);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        ApartamnetAppClass->setStatusBar(statusBar);

        retranslateUi(ApartamnetAppClass);

        QMetaObject::connectSlotsByName(ApartamnetAppClass);
    } // setupUi

    void retranslateUi(QMainWindow *ApartamnetAppClass)
    {
        ApartamnetAppClass->setWindowTitle(QCoreApplication::translate("ApartamnetAppClass", "ApartamnetApp", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ApartamnetAppClass: public Ui_ApartamnetAppClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_APARTAMNETAPP_H
